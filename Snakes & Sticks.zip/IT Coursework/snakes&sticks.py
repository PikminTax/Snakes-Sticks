import pygame
import time
import random


pygame.init()
pygame.mixer.init()

#fps
clock = pygame.time.Clock()
clock.tick(24)

#animation
SwordAnim = True
GunAnim = False

#variables for text
FONT = pygame.font.Font("FFFFORWA.TTF",12)
white = (255,255,255)
count = 0

#combat variables
#P = Player
#E = Enemy
widthP = 200
heightP = 50                  
widthE = 200
heightE = 50
winner = 0
Swordattack = True
Gunattack = False
BackSwitch = False
BackItem = False
chipsitem = 2
colaitem = 3
green = (0,255,0)
cactus_event = False
cactus_eventSTOP = 0
SwitchA = False
AttackA = False
ItemA = False
playerwon = False
enemywon = False
#hitbox
hitbox = pygame.Rect(275,500, 40, 40)
hitboxC = pygame.Rect(370,490, 40, 40)
#music variables
MainGameM = True
MainMenuM = True
#Item Healing/effects
cola = 40
chips = 60
Nothing = 0

#misc variables
goaway = 0
SoundEffect = 1
MusicVolume = 1


#game instances 
MainMenu = pygame.display.set_mode((600, 600))

#name of the window
pygame.display.set_caption("Snakes & Sticks")
#============================================================= Images ==========
#button images
start_btn_image = pygame.image.load("NewGameButton.png")
exit_btn_image = pygame.image.load("ExitGameButton.png")
Settingsbutton = pygame.image.load("SettingsButton.png")
PlusVol = pygame.image.load("PlusVolume.png")
NegVol = pygame.image.load("MinusVolume.png")
Controls = pygame.image.load("Controls.png")
#background image
bg1 = pygame.image.load("MainMenu.png")
bg = pygame.image.load("MiddleOfKnowWhereBar.png")
#sprites for walking + standing still
walkRight = [pygame.image.load("MovingStickmanRight1.png"), pygame.image.load("StandingStillStickManRight.png"), pygame.image.load("MovingStickmanRight2.png"), pygame.image.load("StandingStillStickManRight.png")]
walkLeft = [pygame.image.load("MovingStickmanLeft1.png"), pygame.image.load("StandingStillStickmanLeft.png"), pygame.image.load("MovingStickmanLeft2.png"), pygame.image.load("StandingStillStickManLeft.png")]
walkUp = [pygame.image.load("MovingStickmanBehind1.png"), pygame.image.load("StandingStillStickManBehind.png"), pygame.image.load("MovingStickmanBehind2.png"), pygame.image.load("StandingStillStickManBehind.png")]
walkDown = [pygame.image.load("MovingStickmanFront1.png"), pygame.image.load("StandingStillStickManFront.png"), pygame.image.load("MovingStickmanFront2.png"), pygame.image.load("StandingStillStickManFront.png")]
Still = pygame.image.load("StandingStillStickmanFront.png")
#sprites for Tutorial guy
TutorialGuy = pygame.image.load("TutorialStickmanFront.png")        
#Idle Animations
IdleLeft =pygame.image.load("StandingStillStickmanLeft.png")
IdleRight = pygame.image.load("StandingStillStickmanRight.png")
IdleUp = pygame.image.load("StandingStillStickmanBehind.png")
IdleDown = pygame.image.load("StandingStillStickmanFront.png")
#Misc
MusicSetting = pygame.image.load("MusicVolume.png")
SoundEffectSetting = pygame.image.load("SoundEffectVolume.png")
Keybinds = pygame.image.load("KeyBinds.png")
No0 = pygame.image.load("No0.png")
No1 = pygame.image.load("No1.png")
No2 = pygame.image.load("No2.png")
No3 = pygame.image.load("No3.png")
No4 = pygame.image.load("No4.png")
No5 = pygame.image.load("No5.png")
No6 = pygame.image.load("No6.png")
No7 = pygame.image.load("No7.png")
No8 = pygame.image.load("No8.png")
No9 = pygame.image.load("No9.png")
No10 = pygame.image.load("No10.png")
Textbox = pygame.image.load("TextBox.png")
TalkPopUp = pygame.image.load("Talk.png")
NoButton = pygame.image.load("NoButton.png")
YesButton = pygame.image.load("YesButton.png")
GasStation = pygame.image.load("GasStation.png")
youwonshoo = pygame.image.load("YouwonShoo.png")
TestingBox = pygame.image.load("blackboxfortesting.png")
OverWrite = pygame.image.load("OverWrite.png")
OverWriteOS = pygame.image.load("OverWriteOtherside.png")
SwordOverWrite = pygame.image.load("SwordOverWrite.png")
OverWriteTopHat = pygame.image.load("OverWriteTopHat.png")
OverWriteHatOSHat = pygame.image.load("OverWriteTopHatOtherSide.png")
OverWriteSwordAnim = pygame.image.load("OverWriteSwordAnim.png")
GunIcon = pygame.image.load("GunIcon.png")
SwordIcon = pygame.image.load("KnifeIcon.png")
TophatIcon = pygame.image.load("TophatIcon.png")
#combat images
RedHP = pygame.image.load("BackgroundHP.png")
background = pygame.image.load("CombatBackgroundv2.png")
StickmanAttack = pygame.image.load("AttackingStickman.png")
TutorialAttack = pygame.image.load("AttackingTutorialguy.png")
combatwin = pygame.image.load("winner.png")
combatlose = pygame.image.load("loser.png")
ItemInv = pygame.image.load("ItemInventory.png")
Stupid = pygame.image.load("StupidTxt.png")
Black = pygame.image.load("BlackTxtBox.png")
StickmanAttackSword = pygame.image.load("AttackingStickmanSword.png")
StickmanAttackGun = pygame.image.load("AttackingStickmanGun.png")
StickmanColaDrink1 = pygame.image.load("StickmanCOLA.png")
StickmanColaDrink2 = pygame.image.load("StickmanCOLA1.png")
StickmanHealSword1 = pygame.image.load("StickmanHEALTakenSword1.png")
StickmanHealSword2 = pygame.image.load("StickmanHEALTakenSword2.png")
StickmanHealSword3 = pygame.image.load("StickmanHEALTakenSword3.png")
StickmanHealGun1 = pygame.image.load("StickmanHEALTakenGun1.png")
StickmanHealGun2 = pygame.image.load("StickmanHEALTakenGun2.png")
StickmanHealGun3 = pygame.image.load("StickmanHEALTakenGun3.png")
TutorialDMGTaken1 = pygame.image.load("TutorialDMGTaken1.png")
TutorialDMGTaken2 = pygame.image.load("TutorialDMGTaken2.png")
TutorialDMGTaken3 = pygame.image.load("TutorialDMGTaken3.png")
StickmanSwordAttack1 = pygame.image.load("AttackingSwordAnimation1.png")
StickmanSwordAttack2 = pygame.image.load("AttackingSwordAnimation2.png")
StickmanSwordAttack3 = pygame.image.load("AttackingSwordAnimation3.png")
TutorialSwordDMGTaken = pygame.image.load("TutorialDMGTakenFromSword.png")
StickmanDMGTakenSword1 = pygame.image.load("StickmanDMGTakenSword1.png")
StickmanDMGTakenSword2 = pygame.image.load("StickmanDMGTakenSword2.png")
StickmanDMGTakenSword3 = pygame.image.load("StickmanDMGTakenSword3.png")
StickmanDMGTakenGun1 = pygame.image.load("StickmanDMGTakenGun1.png")
StickmanDMGTakenGun2 = pygame.image.load("StickmanDMGTakenGun2.png")
StickmanDMGTakenGun3 = pygame.image.load("StickmanDMGTakenGun3.png")
TutorialGuyAttackHat1 = pygame.image.load("TutorialTopHatAttack1.png")
TutorialGuyAttackHat2 = pygame.image.load("TutorialTopHatAttack2.png")
TutorialGuyAttackHat3 = pygame.image.load("TutorialTopHatAttack3.png")
TutorialGuyAttackHat4 = pygame.image.load("TutorialTopHatAttack4.png")
StickmanEatChip1 = pygame.image.load("StickmanCHIP1.png")
StickmanEatChip2 = pygame.image.load("StickmanCHIP2.png")
NoHat = pygame.image.load("AttackingTutorialguyNoHat.png")


#buttons combat images
SwitchButton = pygame.image.load("SwitchButton.png")
ItemButton = pygame.image.load("ItemButton.png")
AttackButton = pygame.image.load("AttackButton.png")
Cola = pygame.image.load("ColaButton.png")
Chips = pygame.image.load("ChipsButton.png")
SwordButton = pygame.image.load("SwordButton.png")
GunButton = pygame.image.load("GunButton.png")
BackButton = pygame.image.load("BackButton.png")
NoCola = pygame.image.load("NoColaLeft.png")
NoChips = pygame.image.load("NoChipsLeft.png")

#Music
MainMenuTheme = pygame.mixer.Sound("royalfreeevil.mp3")
MainGameTheme = pygame.mixer.Sound("maingame.mp3")
CombatTheme = pygame.mixer.Sound("combatmusic.mp3")
DMGtaken = pygame.mixer.Sound("hurtnoise.wav")
#SwordAttack = pygame.mixer.Sound(".mp3")
#GunAttack = pygame.mixer.Sound(".mp3")
#EnemyAttack = pygame.mixer.Sound(".mp3")
#SwordSwitch = pygame.mixer.Sound(".mp3")
#GunSwitch = pygame.mixer.Sound(".mp3")
ColaDrank = pygame.mixer.Sound("canopen.flac")
ChipsEaten = pygame.mixer.Sound("eatingnoise.wav")
#TalkingTutorial = pygame.mixer.Sound(".mp3")
#MiscTalking = pygame.mixer.Sound(".mp3")

#this music cannot stay need to change eventually

#sound effect volume variables
SoundEffect = 1

def MainMenuMusic():
    pygame.mixer.music.load("royalfreeevil.mp3")
    pygame.mixer.music.play(-1)
    pygame.mixer.music.set_volume(MusicVolume)

#attempt to actually get the audio i WANTED for the main game not this. But its fine atm.
def MainGameMusic():
    pygame.mixer.music.load("maingame.mp3")
    pygame.mixer.music.play(-1)
    pygame.mixer.music.set_volume(MusicVolume)

def ColaDrink():
    pygame.mixer.Sound.play(ColaDrank)
    ColaDrank.set_volume(SoundEffect)

#need a better sound effect perhaps the nom nom nom from roblox/tf2
def ChipsEat():
    pygame.mixer.Sound.play(ChipsEaten)
    ChipsEaten.set_volume(SoundEffect)

#need a higher pitch one for the enemy or another alternative
def DMGtake():
    pygame.mixer.Sound.play(DMGtaken)
    DMGtaken.set_volume(SoundEffect)

def CombatGameMusic():
    pygame.mixer.music.load("combatmusic.mp3")
    pygame.mixer.music.play(-1)
    pygame.mixer.music.set_volume(MusicVolume)
#============================================================= Images ==========
#dialogue code
def getSurfaces(word,pos):
    global previousWidth

    surfaces = []
    positions = []
    for i in range(len(word)):
        surf = FONT.render(f"{word[i]}", True, white)
        surfaces.append(surf)
    for i in range(len(surfaces)):
        previousWidth += surfaces[i-1].get_rect().width
        positions.append([previousWidth + pos[0], pos[1]])
    return surfaces, positions


class Button():
    def __init__(self, x, y, image):
        self.image = image
        self.rect = self.image.get_rect()
        self.rect.topleft = (x, y)
        self.clicked = False
        
    def draw(self, MainMenu):
        action = False
        pos = pygame.mouse.get_pos()
        if self.rect.collidepoint(pos):
            if pygame.mouse.get_pressed()[0] and not self.clicked:
                action = True
                self.clicked = True
                        
        if not pygame.mouse.get_pressed()[0]:
            self.clicked = False
                    
        MainMenu.blit(self.image, self.rect)
        return action

#====================================================== Buttons =================
#button instances
#menu buttons
start_btn = Button(0, 25, start_btn_image)
exit_btn = Button(100, 25, exit_btn_image)
#Settings
Settings_btn = Button(200, 25, Settingsbutton)
PlusSound_btn = Button(100, 200, PlusVol)
NegSound_btn = Button(400, 200, NegVol)
PlusMusic_btn = Button(100, 0, PlusVol)
NegMusic_btn = Button(400, 0, NegVol)
Controls_btn = Button(200, 400, Controls)
#combat start buttons
No_btn = Button(300, 215, NoButton)
Yes_btn = Button(220, 215, YesButton)
#Switch
Sword_btn = Button(390, 498, SwordButton)
Gun_btn = Button(10, 498, GunButton) 
#switch + item button
Back_btn = Button(200, 498, BackButton)
#button instances
Switch_btn = Button(200, 498, SwitchButton)
Item_btn = Button(390, 498, ItemButton)
Attack_btn = Button(10, 498, AttackButton)
#Items
Cola_btn = Button(10, 498, Cola)
Chips_btn = Button(390, 498, Chips)
#====================================================== Buttons =================


run = True
MainMenuMusic()
while run:
    MainMenu.blit(bg1, (0,0))

    
        
#button options
    if exit_btn.draw(MainMenu):
        run = False
        
    if Settings_btn.draw(MainMenu):
        print("help")
        SettingsTab = True
        
        while SettingsTab:
            
            pygame.event.get()
            
            SettingsPleaseWork = pygame.display.set_mode((600,600))
            
            SettingsPleaseWork.blit(bg1, (0,0))
            
            pygame.display.set_caption("Snakes & Sticks")
            
            SettingsPleaseWork.blit(SoundEffectSetting, (200,200))
            
            if Back_btn.draw(SettingsPleaseWork):
                SettingsTab = False
                
#============================================================ Sound Effects =======================
            if NegSound_btn.draw(SettingsPleaseWork):
                SoundEffect = SoundEffect - 1
                
            if PlusSound_btn.draw(SettingsPleaseWork):
                SoundEffect = SoundEffect + 1

            if SoundEffect == 10:
                SettingsPleaseWork.blit(No10, (200,300))
                
            if SoundEffect == 9:
                SettingsPleaseWork.blit(No9, (200,300))
                
            if SoundEffect == 8:
                SettingsPleaseWork.blit(No8, (200,300))
                
            if SoundEffect == 7:
                SettingsPleaseWork.blit(No7, (200,300))
                
            if SoundEffect == 6:
                SettingsPleaseWork.blit(No6, (200,300)) 
                
            if SoundEffect == 5:
                SettingsPleaseWork.blit(No5, (200,300))
                
            if SoundEffect == 4:
                SettingsPleaseWork.blit(No4, (200,300)) 
                
            if SoundEffect == 3:
                SettingsPleaseWork.blit(No3, (200,300)) 
                
            if SoundEffect == 2:
                SettingsPleaseWork.blit(No2, (200,300))
                
            if SoundEffect == 1:
                SettingsPleaseWork.blit(No1, (200,300)) 
                
            if SoundEffect == 0:
                SettingsPleaseWork.blit(No0, (200,300)) 
                
            if SoundEffect >= 10:
                SoundEffect = 10
                SettingsPleaseWork.blit(No10, (200,300))
                print ("Positive Limit")
                
            if SoundEffect <= 0:
                SoundEffect = 0
                SettingsPleaseWork.blit(No0, (200,300))
                print ("Negative Limit")
#============================================================ Sound Effects =======================
                
#============================================================ Music Volume ========================
            SettingsPleaseWork.blit(MusicSetting, (200,0))
                
            if NegMusic_btn.draw(SettingsPleaseWork):
                MusicVolume = MusicVolume - 1
                
            if PlusMusic_btn.draw(SettingsPleaseWork):
                MusicVolume = MusicVolume + 1

            if MusicVolume == 10:
                SettingsPleaseWork.blit(No10, (200,100))
                
            if MusicVolume == 9:
                SettingsPleaseWork.blit(No9, (200,100))
                
            if MusicVolume == 8:
                SettingsPleaseWork.blit(No8, (200,100))
                
            if MusicVolume == 7:
                SettingsPleaseWork.blit(No7, (200,100))
                
            if MusicVolume == 6:
                SettingsPleaseWork.blit(No6, (200,100)) 
                
            if MusicVolume == 5:
                SettingsPleaseWork.blit(No5, (200,100))
                
            if MusicVolume == 4:
                SettingsPleaseWork.blit(No4, (200,100)) 
                
            if MusicVolume == 3:
                SettingsPleaseWork.blit(No3, (200,100)) 
                
            if MusicVolume == 2:
                SettingsPleaseWork.blit(No2, (200,100))
                
            if MusicVolume == 1:
                SettingsPleaseWork.blit(No1, (200,100)) 
                
            if MusicVolume == 0:
                SettingsPleaseWork.blit(No0, (200,100)) 
                
            if MusicVolume >= 10:
                MusicVolume = 10
                SettingsPleaseWork.blit(No10, (200,100))
                print ("Positive Limit")
                
            if MusicVolume <= 0:
                MusicVolume = 0
                SettingsPleaseWork.blit(No0, (200,100))
                print ("Negative Limit")
                
#============================================================ Music Volume ========================
              
#============================================================ Controls ============================
            if Controls_btn.draw(SettingsPleaseWork):
                ControlsTab = True
                print("Controls")
                
                while ControlsTab:              
                                   
                    pygame.event.get()
                    
                    ControlsPleaseWork = pygame.display.set_mode((600,600))
                    
                    ControlsPleaseWork.blit(bg1, (0,0))
                    
                    pygame.display.set_caption("Snakes & Sticks")
                        
                    if Back_btn.draw(ControlsPleaseWork):
                        ControlsTab = False
                    
                    ControlsPleaseWork.blit(Keybinds, (100,80))
                        
                    pygame.display.update()
#============================================================ Controls ============================
            pygame.display.update()
            


            
            

#game code
    if start_btn.draw(MainMenu):
        
        MainMenuM = False
        
        
        MainGame = pygame.display.set_mode((600, 600))
        
        MainGameMusic()
       
        #defining the main player with all the variables
        class player(object):
            def __init__(self,x,y,width,height):
                self.x = x
                self.y = y
                self.width = width
                self.height = height
                self.vel = 3 #vel = how fast the sprite move on the screen / 3 vel = 3 pixels
                self.left = False
                self.right = False
                self.up = False
                self.down = False
                self.walkCount = 0
                self.direction = 1
                self.hitboxP = pygame.Rect(self.x, self.y+50, 100, 50)

            def draw(self):


                #movement and sprite updating
                if self.walkCount + 1 >= 12: #12 sprites in total
                    self.walkCount = 0

                if self.left:
                    MainGame.blit(walkLeft[self.walkCount//3], (self.x,self.y)) #//3 because of 3 sprites needing to be displayed so it cycles though each 3 of them
                    self.walkCount += 1

                elif self.right:
                    MainGame.blit(walkRight[self.walkCount//3], (self.x,self.y))
                    self.walkCount += 1

                elif self.up:
                    MainGame.blit(walkUp[self.walkCount//3], (self.x,self.y))
                    self.walkCount += 1

                elif self.down:
                    MainGame.blit(walkDown[self.walkCount//3], (self.x,self.y))
                    self.walkCount += 1

                #Idle animations
                else:
                    if self.direction == 1:
                        MainGame.blit(IdleDown,(self.x,self.y))
                    elif self.direction == 2:
                        MainGame.blit(IdleUp,(self.x,self.y))
                    elif self.direction == 3:
                        MainGame.blit(IdleLeft,(self.x,self.y))
                    elif self.direction == 4:
                        MainGame.blit(IdleRight,(self.x,self.y))
                        
                self.hitboxP = pygame.Rect(self.x+25, self.y+70, 50, 25)
                
        

        def redrawGameWindow():     

            MainGame.blit(bg, (0, 0))
            
            class Button():
                def __init__(self, x, y, image):
                    self.image = image
                    self.rect = self.image.get_rect()
                    self.rect.topleft = (x, y)
                    self.clicked = False
            
                def draw(self, MainGame):
                    action = False
                    pos = pygame.mouse.get_pos()
                    if self.rect.collidepoint(pos):
                        if pygame.mouse.get_pressed()[0] and not self.clicked:
                            action = True
                            self.clicked = True
                            
                        if not pygame.mouse.get_pressed()[0]:
                            self.clicked = False
                        
                    MainGame.blit(self.image, self.rect)
                    return action

            Stickman.draw()

            #Tutorial guy
            MainGame.blit(TutorialGuy, (0,430))
            
            
            #uncomment these for testing hitboxes
            #pygame.draw.rect(MainGame, (255,255,0), hitbox)
            
            #pygame.draw.rect(MainGame, (255,0,0), Stickman.hitboxP)
            
            #pygame.draw.rect(MainGame, (255,0,255), hitboxC)

            pygame.display.update()


        
        #players placement = y500 x80, sprite size = 100x100
        Stickman = player(80, 500, 100, 100)
        
#===================================================================== Main Loop =================================
        while True:

            pygame.event.get()
            
            clock.tick(24)

            keys = pygame.key.get_pressed()
            
            #left
            if keys[pygame.K_a] and Stickman.x > Stickman.vel:
                if Stickman.x < 80:
                    Stickman.x += Stickman.vel
                    Stickman.left = False
                    Stickman.right = False
                    Stickman.up = False
                    Stickman.down = False
                Stickman.x -= Stickman.vel
                Stickman.left = True
                Stickman.right = False
                Stickman.up = False
                Stickman.down = False
                Stickman.direction = 3
            #right   
            elif keys[pygame.K_d] and Stickman.x < 600 - Stickman.width - Stickman.vel:
                Stickman.x += Stickman.vel
                Stickman.right = True
                Stickman.left = False
                Stickman.up = False
                Stickman.down = False
                Stickman.direction = 4
            #up  
            elif keys[pygame.K_w] and Stickman.y > Stickman.vel:
                if Stickman.y < 420:
                    Stickman.y += Stickman.vel
                    Stickman.up = False
                    Stickman.down = False
                    Stickman.left = False
                    Stickman.right = False
                Stickman.y -= Stickman.vel
                Stickman.up = True
                Stickman.left = False
                Stickman.right = False
                Stickman.down = False
                Stickman.direction = 2
            #down
            elif keys[pygame.K_s] and Stickman.y < 600 - Stickman.height - Stickman.vel:
                Stickman.y += Stickman.vel
                Stickman.down = True
                Stickman.left = False
                Stickman.right = False
                Stickman.up = False
                Stickman.direction = 1  
            #not moving
            else:
                Stickman.right = False
                Stickman.left = False
                Stickman.up = False
                Stickman.down = False
                Stickman.walkCount = 0
#================================================================================================== Dialogue code ==========          
            if keys[pygame.K_e] and Stickman.hitboxP.colliderect(hitboxC):
                word = "*You poke and prod the cactus expecting something*"
                pygame.event.get()
                
                    
                previousWidth = 0

                surfaces, positions = getSurfaces(word, [14,150])

                start = time.time()
                count = 0
                def cactus_dialogue1(delay = 0.06):
                    global count
                    global start
                    now = time.time()
                    if count < len(surfaces):
                        if now - start > delay:
                            count +=1
                            print(count)
                            start = now
                    for i in range(count):
                        MainGame.blit(surfaces[i], (positions[i][0], positions[i][1]))
                        
                while True:
                    MainGame.blit(Textbox,(15,100))
                    cactus_dialogue1()
                    pygame.display.update()
                
                    if count == 50:
                        time.sleep(2)
                        break
                    
                    elif cactus_event == True:
                        break
                    
                    else:
                        pass
                    
            #elif cactus_eventSTOP >= 1:
                #word = "STOP TOUCHING THE CACTUS *Stickman -20 HP*"
                #pygame.event.get()
                #cactus_eventSTOP += 20
                
                    
                #previousWidth = 0

                #surfaces, positions = getSurfaces(word, [14,150])

                #start = time.time()
                #count = 0
                #def cactus_dialogueSTOP(delay = 0.06):
                    #global count
                    #global start
                    #now = time.time()
                    #if count < len(surfaces):
                        #if now - start > delay:
                            #count +=1
                            #print(count)
                            #start = now
                    #for i in range(count):
                        #MainGame.blit(surfaces[i], (positions[i][0], positions[i][1]))
                        
                #while True:
                    #MainGame.blit(Textbox,(15,100))
                    #cactus_dialogueSTOP()
                    #pygame.display.update()
                
                    #if count == 42:
                        #time.sleep(2)
                        #break
                    
#================================================================================================================# 
            if keys[pygame.K_e] and count == 50:
                pygame.event.get()
                word = "*Stickman -20 HP* Nice one, what did you expect?"
                cactus_event = True
                
                previousWidth = 0
                
                surfaces, positions = getSurfaces(word, [14,150])

                start = time.time()
                count = 0
                def cactus_dialogue2(delay = 0.06):
                    global count
                    global start
                    now = time.time()
                    if count < len(surfaces):
                        if now - start > delay:
                            count +=1
                            print(count)
                            start = now
                    for i in range(count):
                        MainGame.blit(surfaces[i], (positions[i][0], positions[i][1]))
                        
                while True:
                    MainGame.blit(Textbox,(15,100))
                    cactus_dialogue2()
                    pygame.display.update()
                
                    if count == 48:
                        time.sleep(2)
                        cactus_eventSTOP += 20
                        break
#======================================================= Entering the gas station =========================
            if keys[pygame.K_e] and Stickman.hitboxP.colliderect(hitbox):
                pygame.event.get()

                Combat2 = True
                while Combat2:
                    pygame.event.get()
                    
                    if winner == 1:
                        goaway += 1
                        
                        if goaway == 4:
                            AnnoyingEnding = pygame.display.set_mode((600,600))
                            
                            word = "Annoying Ending... Welldone you brat!... You expect a reward or somethin?"
                            pygame.event.get()
                                
                            previousWidth = 0

                            surfaces, positions = getSurfaces(word, [14,150])
                            
                            start = time.time()
                            count = 0
                            def AnnoyingEnding_dialogue1(delay = 0.06):
                                global count
                                global start
                                now = time.time()
                                if count < len(surfaces):
                                    if now - start > delay:
                                        count +=1
                                        print(count)
                                        start = now
                                for i in range(count):
                                    AnnoyingEnding.blit(surfaces[i], (positions[i][0], positions[i][1]))
                                    
                            while True:
                                AnnoyingEnding.blit(Textbox,(15,100))
                                AnnoyingEnding_dialogue1()
                                pygame.display.update()
                            
                                if count == 37:
                                    time.sleep(1.0)
                                    pygame.quit()
                            
                        pygame.event.get()
                        word = "You won already, bugger off!"
                        
                        
                        previousWidth = 0
                        
                        surfaces, positions = getSurfaces(word, [150,150])

                        start = time.time()
                        count = 0
                        def tutorialguytalkafterwin(delay = 0.06):
                            global count
                            global start
                            now = time.time()
                            if count < len(surfaces):
                                if now - start > delay:
                                    count +=1
                                    print(count)
                                    start = now
                            for i in range(count):
                                MainGame.blit(surfaces[i], (positions[i][0], positions[i][1]))
                                
                        while True:
                            MainGame.blit(Textbox,(15,100))
                            tutorialguytalkafterwin()
                            pygame.display.update()
                            
                            if count == 28:
                                time.sleep(2)
                                Combat2 = False
                                break
                            
                    if goaway == 3:
                        pygame.event.get()
                        word = "Do it one more time, I dare you"
                        
                        
                        previousWidth = 0
                        
                        surfaces, positions = getSurfaces(word, [150,150])

                        start = time.time()
                        count = 0
                        def tutorialguytalkafterwin1(delay = 0.06):
                            global count
                            global start
                            now = time.time()
                            if count < len(surfaces):
                                if now - start > delay:
                                    count +=1
                                    print(count)
                                    start = now
                            for i in range(count):
                                MainGame.blit(surfaces[i], (positions[i][0], positions[i][1]))
                                
                        while True:
                            MainGame.blit(Textbox,(15,100))
                            tutorialguytalkafterwin1()
                            pygame.display.update()
                            
                            if count == 31:
                                time.sleep(2)
                                Combat2 = False
                                break
                            
                            
                    elif winner == 0:
                        MainGame.blit(GasStation,(200,100))
                                                            
                    if No_btn.draw(MainGame) == True:
                        Combat2 = False
                    
#=======================================================Combat Code==================
                    if Yes_btn.draw(MainGame) == True:
                                                    
                        MainGameM = False
                        if MainGameM == False:
                            pygame.mixer.music.stop()
                            CombatGameMusic()
                        
                        Combo = True
                        while Combo:
        
                            pygame.event.get()
                            
                            Combat = pygame.display.set_mode((600,600))
                            
                            pygame.display.set_caption("Snakes & Sticks")
                            
#================================================================== Animations =====================
                            clock.tick(24)
                            
                            #Healing with a sword equiped
                            def HealingSword():
                                HealSword = 0
                                HealSwordA = True
                                while HealSwordA:
                                    HealSword = HealSword+1
                                    Combat.blit(TutorialAttack,(20,280))
                                    Combat.blit(OverWrite,(0,0))
                                    if HealSword < 45:
                                        Combat.blit(StickmanHealSword1,(400,280))
                                    elif HealSword >= 45 and HealSword < 90:
                                        Combat.blit(StickmanHealSword2,(400,280))
                                    elif HealSword >= 90 and HealSword < 135:
                                        Combat.blit(StickmanHealSword3,(400,280))
                                    elif HealSword == 135:
                                        HealSwordA = False
                                    pygame.display.update()
                                    
                            #Player damage taken whilst having gun equiped     
                            def GunDMGTaken():
                                GunDMGTake = 0
                                GunDMGT = True
                                while GunDMGT:
                                    GunDMGTake = GunDMGTake+1
                                    Combat.blit(TutorialAttack,(20,280))
                                    Combat.blit(OverWrite,(0,0))
                                    if GunDMGTake < 45:
                                        Combat.blit(StickmanDMGTakenGun1,(400,280))
                                    elif GunDMGTake >= 45 and GunDMGTake < 90:
                                        Combat.blit(StickmanDMGTakenGun2,(400,280))
                                    elif GunDMGTake >= 90 and GunDMGTake < 135:
                                        Combat.blit(StickmanDMGTakenGun3,(400,280))
                                    elif GunDMGTake == 135:
                                        GunDMGT = False
                                    pygame.display.update()
                            
                            #Player damage taken whilst having the sword equiped
                            def SwordDMGTaken():
                                SwordDMGTake = 0
                                SwordDMGT = True
                                while SwordDMGT:
                                    SwordDMGTake = SwordDMGTake+1
                                    Combat.blit(TutorialAttack,(20,280))
                                    Combat.blit(OverWrite,(0,0))
                                    if SwordDMGTake < 45:
                                        Combat.blit(SwordOverWrite,(0,0))
                                        Combat.blit(StickmanDMGTakenSword1,(400,280))
                                    elif SwordDMGTake >= 45 and SwordDMGTake < 90:
                                        Combat.blit(SwordOverWrite,(0,0))
                                        Combat.blit(StickmanDMGTakenSword2,(400,280))
                                    elif SwordDMGTake >= 90 and SwordDMGTake < 135:
                                        Combat.blit(SwordOverWrite,(0,0))
                                        Combat.blit(StickmanDMGTakenSword3,(400,280))
                                    elif SwordDMGTake == 135:
                                        SwordDMGT = False
                                    pygame.display.update()

                            #The animations for attacking with a sword
                            def SwordAttack():
                                SwordA = 0
                                SwordAtk = True
                                while SwordAtk:
                                    SwordA = SwordA+1
                                    Combat.blit(TutorialAttack,(20,280))
                                    Combat.blit(OverWrite,(0,0))
                                    if SwordA < 90:
                                        Combat.blit(StickmanSwordAttack1,(300,280))
                                    elif SwordA >= 90 and SwordA < 180:
                                        Combat.blit(SwordOverWrite,(0,0))
                                        Combat.blit(StickmanSwordAttack2,(200,280))
                                    elif SwordA >= 210 and SwordA < 240:
                                        Combat.blit(SwordOverWrite,(0,0))
                                        Combat.blit(StickmanSwordAttack3,(190,280))
                                    elif SwordA >= 270 and SwordA < 300:
                                        Combat.blit(TutorialSwordDMGTaken,(20,280))
                                        Combat.blit(OverWriteSwordAnim,(0,0))
                                    elif SwordA == 300:
                                        SwordAtk = False
                                    pygame.display.update()
                                    
                            #The tutorial guys hat attack       
                            def TutorialHatAttack():
                                global SwordAnim
                                global GunAnim
                                
                                HatAttack = 0
                                HatAnims = True
                                while HatAnims:
                                    HatAttack = HatAttack+1
                                    Combat.blit(StickmanAttack,(400,280))  
                                    Combat.blit(OverWriteHatOSHat,(0,0))
                                    if HatAttack < 90:
                                        Combat.blit(TutorialGuyAttackHat1,(20,280))
                                    elif HatAttack >= 90 and HatAttack < 180:
                                        Combat.blit(NoHat,(20,280))
                                        Combat.blit(TutorialGuyAttackHat2,(120,280))
                                    elif HatAttack >= 180 and HatAttack < 270:
                                        Combat.blit(NoHat,(20,280))
                                        Combat.blit(TutorialGuyAttackHat3,(220,280))
                                    elif HatAttack >= 270 and HatAttack < 360:
                                        Combat.blit(NoHat,(20,280))
                                        Combat.blit(TutorialGuyAttackHat4,(320,280))
                                        Combat.blit(TutorialAttack,(20,280))
                                    elif HatAttack == 360:
                                        HatAnims = False
                                    pygame.display.update()
                                        
                            #Player healing with a gun equiped      
                            def HealingGun():
                                HealGun = 0
                                HealGunA = True
                                while HealGunA:
                                    HealGun = HealGun+1
                                    Combat.blit(StickmanAttack,(400,280))     
                                    Combat.blit(OverWrite,(0,0))
                                    if HealGun < 45:
                                        Combat.blit(StickmanHealGun1,(400,280))
                                    elif HealGun >= 45 and HealGun < 90:
                                        Combat.blit(StickmanHealGun2,(400,280))
                                    elif HealGun >= 90 and HealGun < 135:
                                        Combat.blit(StickmanHealGun3,(400,280))
                                    elif HealGun == 135:
                                        HealGunA = False
                                    pygame.display.update()
                                    
                            #Tutorial guy taking damage        
                            def TutorialDMGTaken():
                                TAnim = 0
                                TutorialA = True
                                while TutorialA:
                                    TAnim = TAnim+1
                                    Combat.blit(OverWriteOS,(0,0))
                                    Combat.blit(StickmanAttack,(400,280))
                                    if TAnim < 45:
                                        Combat.blit(TutorialDMGTaken1,(20,280))
                                    elif TAnim >= 45 and TAnim < 90:
                                        Combat.blit(TutorialDMGTaken2,(20,280))
                                    elif TAnim >= 90 and TAnim < 135:
                                        Combat.blit(TutorialDMGTaken3,(20,280))
                                    elif TAnim == 135:
                                        TutorialA = False
                                    pygame.display.update()
                                    
                            #animations for drinking cola
                            def ColaAnimation():
                                ColaAnim = 0
                                ColaA = True
                                while ColaA:
                                    ColaAnim = ColaAnim+1
                                    Combat.blit(TutorialAttack,(20,280))
                                    Combat.blit(OverWrite,(0,0))
                                    if ColaAnim < 120:
                                        Combat.blit(StickmanColaDrink1,(400,280))
                                    elif ColaAnim >= 120 and ColaAnim < 240:
                                        Combat.blit(StickmanColaDrink2,(400,280))
                                    elif ColaAnim == 240:
                                        ColaA = False
                                    pygame.display.update()
                             
                            #animations for eating chips
                            def ChipAnimation():
                                ChipAnim = 0
                                ChipA = True
                                while ChipA:
                                    ChipAnim = ChipAnim+1
                                    Combat.blit(TutorialAttack,(20,280))
                                    Combat.blit(OverWrite,(0,0))
                                    if ChipAnim < 120:
                                        Combat.blit(StickmanEatChip1,(400,280))
                                    elif ChipAnim >= 120 and ChipAnim < 240:
                                        Combat.blit(StickmanEatChip2,(400,280))
                                    elif ChipAnim == 240:
                                        ChipA = False
                                    pygame.display.update()
                                    
#================================================================== End of Animations ================                                      
                            
                            #blitting things on the screen
                            def redrawcombat():
                                
                                pygame.event.get()
                                
                                global enemywon
                                global playerwon
                                
                                class Button():
                                    def __init__(self, x, y, image):
                                        self.image = image
                                        self.rect = self.image.get_rect()
                                        self.rect.topleft = (x, y)
                                        self.clicked = False
                                
                                    def draw(self, Combat):
                                        action = False
                                        pos = pygame.mouse.get_pos()
                                        if self.rect.collidepoint(pos):
                                            if pygame.mouse.get_pressed()[0] and not self.clicked:
                                                action = True
                                                self.clicked = True
                                                        
                                        if not pygame.mouse.get_pressed()[0]:
                                            self.clicked = False
                                                    
                                        Combat.blit(self.image, self.rect)
                                        return action

                                Combat.blit(background,(0,0))

                                Combat.blit(RedHP,(0,20))
                                    
                                Combat.blit(RedHP,(400,20))

                                #player
                                pygame.draw.rect(Combat, green,(0,20,widthE,heightE))
                                #enemy
                                pygame.draw.rect(Combat, green,(400,20,widthP,heightP))

                                #charcters
                                #enemy
                                Combat.blit(TutorialAttack,(20,280))
                                Combat.blit(TophatIcon,(0,70))
                                
                                #player sprite depending on weapon chosen
                                if Swordattack == True:
                                    Combat.blit(StickmanAttackSword,(400, 280))
                                    Combat.blit(SwordIcon,(550,70))

                                if Gunattack == True:
                                    Combat.blit(StickmanAttackGun,(400, 280))
                                    Combat.blit(GunIcon,(550,70))
                                    
                                if widthE <= 0:
                                    Combat.blit(combatwin,(0, 490))
                                    pygame.display.update()
                                    time.sleep(1.5)
                                    playerwon = True
                                    
                                elif widthP <= 0:
                                    Combat.blit(combatlose,(0, 490))
                                    pygame.display.update()
                                    time.sleep(1.5)
                                    enemywon = True
                                    
                            
                                else:
                                    pass
                                
                                pygame.display.update()

                            
                            def Smenu():
                        
                                pygame.event.get()
                                
                                global Swordattack
                                global Gunattack
                                global BackSwitch
                                global SwordAnim
                                global GunAnim
                                
                                print(Swordattack)
                                                                
                                Smenuu = True
                                while Smenuu == True:
                                    
                                    pygame.event.get()
                                    
                                    if Sword_btn.draw(Combat) == True:
                                        print("YOU TAPPED THE SWORD BUTTON")
                                        SwordAnim = True
                                        GunAnim = False
                                        Swordattack = True
                                        Gunattack = False
                                        BackSwitch = False
                                        Smenuu = False

                                    if Gun_btn.draw(Combat) == True:
                                        print("YOU TAPPED THE GUN BUTTON")
                                        GunAnim = True
                                        SwordAnim = False
                                        Swordattack = False
                                        Gunattack = True
                                        BackSwitch = False
                                        Smenuu = False
                                        
                                    if Back_btn.draw(Combat) == True:
                                        Smenuu = False
                                        BackSwitch = True
                                        
                                    pygame.display.update()
                            
                            def Imenu():
                                
                                pygame.event.get()
                                
                                global chipsitem
                                global colaitem
                                global BackItem
                                global widthP
                                global Nothing
                                
                                print(chipsitem, "-chips amount")
                                print(colaitem, "-cola amount")
                                
                                Imenuu = True
                                while Imenuu == True:
                                
                                    pygame.event.get()

                                    if Cola_btn.draw(Combat) == True and colaitem >= 1:
                                        ColaAnimation()
                                        ColaDrink()
                                        
                                        #code that should of made it that if your health is greater then the variable 200 then it gives nothing didnt work but keep for future
                                        #if widthP >= widthP:
                                            #widthP = widthP + Nothing
                                        
                                        #else:
                                        widthP = widthP + cola

                                        
                                        if SwordAnim == True:
                                            HealingSword()
                                            
                                        elif GunAnim == True:
                                            HealingGun()
                                        
                                        print(widthP, "-after item")
                                        colaitem = colaitem - 1
                                        Imenuu = False
                                        
                                    elif colaitem <= 0:
                                        Combat.blit(NoCola,(10, 498))
                                        
                                    
                                    if Chips_btn.draw(Combat) == True and chipsitem >= 1:
                                        ChipAnimation()
                                        ChipsEat()
                                        
                                        #code that should of made it that if your health is greater then the variable 200 then it gives nothing didnt work but keep for future
                                        #if widthP >= widthP:
                                            #widthP = widthP + Nothing
                                        
                                        #else:
                                        widthP = widthP + chips
                                        
                                        if SwordAnim == True:
                                            HealingSword()
                                            
                                        elif GunAnim == True:
                                            HealingGun()
                                        
                                        print(widthP, "-after item")
                                        chipsitem = chipsitem - 1
                                        Imenuu = False
                                        
                                    elif chipsitem <= 0:
                                        Combat.blit(NoChips,(390, 498))
                                        
                                    if Back_btn.draw(Combat) == True:
                                        Imenuu = False
                                        BackItem = True
                                    
                                    
                                    pygame.display.update()

                                
                            redrawcombat()

                            
                            def ButtonCombat():
                                
                                pygame.event.get()
                                
                                global SwitchA
                                global AttackA
                                global ItemA
                                global widthE
                                global SwitchA
                                global ItemA
                                global AttackA
                                pygame.event.get()

                                sworddmg = random.randint(10, 45)
                                #Not used yet its for later enemys like the snakes
                                #weaktosword = random.randint(30, 80)
                                gundmg = random.randint(20, 38)
                                weaktogun = random.randint(25, 60)
                            
                                #if they choose switch make it so that it takes you to a seperate screen that displays two new buttons that say Gun and Sword
                                if Switch_btn.draw(Combat) == True:
                                    SwitchA = True
                                    Smenu()
                                    
                                    if BackSwitch == True:
                                        SwitchA = False
                                        
                                    else:
                                        pass


                                if Item_btn.draw(Combat) == True:
                                    ItemA = True
                                    Imenu()
                                    
                                    if BackItem == True:
                                        ItemA = False
                                        
                                    else:
                                        pass
                                    
                                       
                                if Attack_btn.draw(Combat) == True:
                                    enemyweaktogun = True
                                    AttackA = True
                                    if Swordattack == True:
                                        SwordAttack()
                                        widthE = widthE - sworddmg
                                        print(sworddmg," -Enemy Damage taken after Stab")
                                        TutorialDMGTaken()

                                        
                                    if Gunattack == True:
                                        if enemyweaktogun == True:
                                            widthE = widthE - weaktogun
                                            redrawcombat()
                                            print(weaktogun," -Hes weak to guns")
                                            TutorialDMGTaken()

                                            
                                        else:
                                            widthE = widthE - gundmg
                                            redrawcombat()
                                            print(gundmg," -Enemy Damage taken after Gunshot")
                                            TutorialDMGTaken()

                                            
                                    print(widthE," -Enemy Health")
                                
                                
                            ButtonCombat()  
                        
                            def enemyturn():
                                
                                pygame.event.get()
                                
                                global AttackA
                                global SwitchA
                                global ItemA
                                global widthP
                                global winner
                                global widthE
                                global cactus_event
                                global enemywon
                                global playerwon
                                global Combat2
                                global Combo
                                global MainGameM
                                global GunAnim
                                global SwordAnim

                                
                                enemydmg = random.randint(20, 50)
                                
                                if AttackA == True:
                                    print ("enemy turn")
                                    widthP = widthP - enemydmg
                                    TutorialHatAttack()
                                    if GunAnim == True:
                                        GunDMGTaken()
                                    elif SwordAnim == True:
                                        SwordDMGTaken()
                                    redrawcombat()
                                    DMGtake()
                                    print(enemydmg," -Enemy Damage Delt")
                                    
                                        
                                elif SwitchA == True:
                                    print ("enemy turn")
                                    widthP = widthP - enemydmg
                                    TutorialHatAttack()
                                    if GunAnim == True:
                                        GunDMGTaken()
                                    elif SwordAnim == True:
                                        SwordDMGTaken()
                                    redrawcombat()
                                    DMGtake()
                                    print(enemydmg," -Enemy Damage Delt")
                                    
                                        
                                elif ItemA == True:
                                    print ("enemy turn")
                                    widthP = widthP - enemydmg
                                    TutorialHatAttack()
                                    if GunAnim == True:
                                        GunDMGTaken()
                                    elif SwordAnim == True:
                                        SwordDMGTaken()
                                    redrawcombat()
                                    DMGtake()
                                    print(enemydmg," -Enemy Damage Delt")
                                    
                                if cactus_event == True:
                                    widthP = widthP - cactus_eventSTOP
                                    cactus_event = False
                                                
                                else:
                                    ItemA = False
                                    SwitchA = False
                                    AttackA = False
                                        
                                    
                                if playerwon == True:
                                    print("enemy dead")
                                    MainGameM = True
                                    time.sleep(1.5)
                                    widthP = 200
                                    winner += 1
                                    Combo = False
                                    Combat2 = False
                                    playerwon = False

                                elif enemywon == True:
                                    print("player dead")
                                    MainGameM = True
                                    time.sleep(1.5)
                                    Stickman.x = 80
                                    Stickman.y = 500
                                    widthP = 200
                                    widthE = 200
                                    Combo = False
                                    Combat2 = False
                                    enemywon = False
                                    
                                if MainGameM == True:
                                    MainGameMusic()
                                    CombatTheme.set_volume(0.0)
                                    
                                else:
                                    enemywon = False
                                    playerwon = False
                                    
                                pygame.display.update()
                             
                            enemyturn()
                        
                            
                            pygame.display.update()
                        
#=======================================================End Of Combat Code==================                                                      
                    pygame.display.update()
                    
                        
            #allowing the player to interact with the NPC           
            if keys[pygame.K_e] and Stickman.x <= 88 and Stickman.y <= 450  and Stickman.direction == 3:
#======================================================= dialogue 1 =========================
                word = "Hello lov, you had quite the fall! From that rust bucket."
                pygame.event.get()
                    
                previousWidth = 0

                surfaces, positions = getSurfaces(word, [14,150])
                
                start = time.time()
                count = 0
                def npc_one_dialogue1(delay = 0.06):
                    global count
                    global start
                    now = time.time()
                    if count < len(surfaces):
                        if now - start > delay:
                            count +=1
                            print(count)
                            start = now
                    for i in range(count):
                        MainGame.blit(surfaces[i], (positions[i][0], positions[i][1]))
                        
                while True:
                    MainGame.blit(Textbox,(15,100))
                    npc_one_dialogue1()
                    pygame.display.update()
                
                    if count == 57:
                        time.sleep(1.0)
                        break
                    
                        
                 
#======================================================= dialogue 2 =========================
            if keys[pygame.K_e] and count == 57:
                
                word = "Those Snakes really mugged you of everything!"
                pygame.event.get()
                
                previousWidth = 0

                surfaces, positions = getSurfaces(word, [14,150])

                start = time.time()
                count = 0
                def npc_one_dialogue2(delay = 0.06):
                    global count
                    global start
                    now = time.time()
                    if count < len(surfaces):
                        if now - start > delay:
                            count +=1
                            print(count)
                            start = now
                    for i in range(count):
                        MainGame.blit(surfaces[i], (positions[i][0], positions[i][1]))
                                           
                while True:
                    MainGame.blit(Textbox,(15,100))
                    npc_one_dialogue2()
                    pygame.display.update()

                    if count == 45:
                        time.sleep(1.0)
                        break
                        


#======================================================= dialogue 3 =========================
            if keys[pygame.K_e] and count == 45:
                
                word = "You cant be going around Snork without knowing how to scrap!"
                pygame.event.get()

                previousWidth = 0

                surfaces, positions = getSurfaces(word, [14,150])

                start = time.time()
                count = 0
                def npc_one_dialogue3(delay = 0.06):
                    global count
                    global start
                    now = time.time()
                    if count < len(surfaces):
                        if now - start > delay:
                            count +=1
                            print(count)
                            start = now
                    for i in range(count):
                        MainGame.blit(surfaces[i], (positions[i][0], positions[i][1]))
                                           
                while True:
                    MainGame.blit(Textbox,(15,100))
                    npc_one_dialogue3()
                    pygame.display.update()

                    if count == 60:
                        time.sleep(1.0)
                        break


#======================================================= dialogue 4 =========================
            if keys[pygame.K_e] and count == 60:
                word = "Fear not Ill teach you, they dont call me the Tutorial for nothin!"
                pygame.event.get()

        
                previousWidth = 0

                surfaces, positions = getSurfaces(word, [14,150])

                start = time.time()
                count = 0
                def npc_one_dialogue4(delay = 0.06):
                    global count
                    global start
                    now = time.time()
                    if count < len(surfaces):
                        if now - start > delay:
                            count +=1
                            print(count)
                            start = now
                    for i in range(count):
                        MainGame.blit(surfaces[i], (positions[i][0], positions[i][1]))
                                           
                while True:
                    MainGame.blit(Textbox,(15,100))
                    npc_one_dialogue4()
                    pygame.display.update()

                    if count == 66:
                        time.sleep(1.0)
                        break


#======================================================= dialogue 5 =========================
            if keys[pygame.K_e] and count == 66:
                word = "Just come on over to my Gas station when youre ready!"
                pygame.event.get()


                previousWidth = 0

                surfaces, positions = getSurfaces(word, [14,150])

                start = time.time()
                count = 0
                def npc_one_dialogue5(delay = 0.06):
                    global count
                    global start
                    now = time.time()
                    if count < len(surfaces):
                        if now - start > delay:
                            count +=1
                            print(count)
                            start = now
                    for i in range(count):
                        MainGame.blit(surfaces[i], (positions[i][0], positions[i][1]))
                                           
                while True:
                    MainGame.blit(Textbox,(15,100))
                    npc_one_dialogue5()
                    pygame.display.update()

                    if count == 52:
                        time.sleep(1.0)
                        break


            #draws the sprites and background and other images on screen
            redrawGameWindow()
            
        if MainGameM == True:
            MainGameMusic()
#==========================================================================================#

    pygame.display.update()

    events = pygame.event.get()
    for event in events:
        if event.type == pygame.QUIT:
            run = False
        
    pygame.display.update()
       
pygame.quit()




